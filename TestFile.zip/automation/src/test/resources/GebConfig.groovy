/*
    This is the Geb configuration file.
    See: http://www.gebish.org/manual/current/#configuration
*/


import org.openqa.selenium.firefox.FirefoxDriver
import util.common.environment.TestContext
import org.openqa.selenium.chrome.ChromeDriver
import org.openqa.selenium.safari.SafariDriver
import org.openqa.selenium.firefox.FirefoxDriver

/**
 *  Example 1. Run tests from command line in Smoke environment:
 *      ./gradlew test -Dgeb.env=smokeChrome
 *
 *  Example 2. Run tests from command line in Test environment with "locale" argument:
 *      ./gradlew test -Dgeb.env=smokeFirefox -Dlocale="en-US"
 */

// set browser

def browser = System.properties.getProperty("browser")

println "got browser: $browser"

switch (browser) {
    case "chrome":
        driver = { setDriverInstance(new ChromeDriver()) }
        break
    case "safari":
        driver = { setDriverInstance(new SafariDriver()) }
        break
    case "firefox":
        driver = { setDriverInstance(new FirefoxDriver()) }
        break
    default:
        driver = { setDriverInstance(new ChromeDriver()) }
        println "fallback to Chrome browser"
}

/**
 *  - Save a reference to the driver browser instance in a globally accessible object of type 'GlobalBrowserInstance'
 *  - Used to acquire driver instance in our listener class 'TakeScreenshotIfTestFailsListener'
 *
 *  NOTE: check 'SpockListener' implementation for more details.
 */
static setDriverInstance(def driverInstance) {
    TestContext.driver = driverInstance
    driverInstance
}

waiting {
    timeout = 30
    retryInterval = 0.5
    presets {
        slow {
            timeout = 120
        }
    }
    baseNavigatorWaiting = true
    atCheckWaiting = true
}

includeCauseInMessage = true

baseUrl = TestContext.env.baseUrl
reportsDir = "build/reports"

// Report test failures only:
// reportOnTestFailureOnly = true