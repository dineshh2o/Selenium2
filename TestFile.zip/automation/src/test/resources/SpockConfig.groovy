import util.common.environment.EnvironmentHelper
import util.common.environment.TestContext
import util.common.annotation.*

runner {

    def suite = System.properties.getProperty("suite")

    // handling suite parameter
    println "got suite parameter: $suite"

    def smoke = 'smoke'
    def regression = 'regression'

    if (suite && suite.equalsIgnoreCase(smoke)) {
        include Smoke
    }
    else if (suite && suite.equalsIgnoreCase(regression)) {
        include Regression
    }

    // handling environment parameter
    def env = System.properties.getProperty("env")
    println "got env parameter: $env"

    if (!env) {
        env = "local"
        println "fallback to $env environment"
    }
    TestContext.env = EnvironmentHelper.getEnvironment(env)
}

