package spec.wlko.retailEvents

import model.Customer
import model.DataProcessTask
import pageObject.page.HomePage
import pageObject.page.LoginPage
import pageObject.page.MyAccountPage
import pageObject.page.ResetPassword
import spec.CommonGebSpec
import util.common.adminconsole.ImpexRunner
import util.wlko.flexibleSearch.GetCustomerData
import util.wlko.flexibleSearch.GetREData

class CustomerRE extends CommonGebSpec {


    def "CustomerCreated RE contains correct fields"() {
        given:
        Customer customer = new Customer()
        to(HomePage).clickMyAccount()

        when:
        at(LoginPage).fillAndSubmitRegistrationForm(customer)
        DataProcessTask dpt = GetREData.GetDPTDetails()

        then:
        dpt.payload.retailEvents.eventType.first() == "CUSTOMER_ACCOUNT_CREATED"
        with(dpt.payload.retailEvents.customer) {
            customerStatus.first() == "REGISTERED"
            email.first() == customer.email
            title.first() + '.' == customer.title.toUpperCase()
            firstName.first() == customer.firstName
            lastName.first() == customer.lastName
        }
    }

    def "CustomerPasswordUpdated RE contains correct fields"() {
        given:
        Customer customer = new Customer()
        ImpexRunner.executeImpex(ImpexRunner.customerAddImpex, customer)
        to(LoginPage).resetPassword(customer.email)

        when:
        String token = GetCustomerData.getCustomerToken(customer)
        to(ResetPassword, token).changePassword(customer.password)
        DataProcessTask dpt = GetREData.GetDPTDetails()

        then:
        dpt.payload.retailEvents.eventType.first() == "CUSTOMER_PASSWORD_UPDATED"
        with(dpt.payload.retailEvents.customer) {
            customerStatus.first() == "REGISTERED"
            customerID.first() == customer.customerId
            email.first() == customer.email
            title.first() + '.' == customer.title.toUpperCase()
            firstName.first() == customer.firstName
            lastName.first() == customer.lastName
        }

    }

    def "CustomerEmailUpdated RE contains correct fields"() {
        given:
        Customer customer = new Customer()
        ImpexRunner.executeImpex(ImpexRunner.customerAddImpex, customer)
        to(LoginPage).login(customer.email, customer.password)

        when:
        to(MyAccountPage).updateEmail(customer.email, customer.password)
        DataProcessTask dpt = GetREData.GetDPTDetails()

        then:
        dpt.payload.retailEvents.eventType.first() == "CUSTOMER_EMAIL_UPDATED"
        with(dpt.payload.retailEvents.customer) {
            customerStatus.first() == "REGISTERED"
            customerID.first() == customer.customerId
            email.first() == customer.email
            title.first() + '.' == customer.title.toUpperCase()
            firstName.first() == customer.firstName
            lastName.first() == customer.lastName
        }
    }
}
