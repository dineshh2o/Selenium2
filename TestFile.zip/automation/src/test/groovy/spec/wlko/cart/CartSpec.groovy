package spec.wlko.cart

import model.StockInfo
import pageObject.page.PDPPage
import pageObject.page.CartPage
import spec.CommonGebSpec
import spock.lang.Shared
import util.wlko.api.DataImport
import util.wlko.flexibleSearch.GetProductData

class CartSpec extends CommonGebSpec {

    @Shared
    def productId

    def setupSpec(){
        productId = GetProductData.getExistingSKU()
    }

    def 'Remove product from cart'() {
        given:
        to(PDPPage, productId)

        when:
        at(PDPPage).addToCart()
        to(CartPage).removeLink.click()
        at(CartPage).confirmationRemoveLink.click()

        then:
        at(CartPage).emptyBasket.isDisplayed()

    }
    def 'Update item with acceptable stock qty'(){
        given:
        def qtyToUpdate = 2

        when:
        to(PDPPage, productId).addToCart()
        to(CartPage).updateItemQty(qtyToUpdate)

        then:
        at(CartPage).successUpdatedQtyAlert.isDisplayed()

    }
    def 'Update qty to exceed stock'(){
        given:
        def itemQtyToUpdate = 4
        def stockQty = 3
        def stock = new StockInfo(code: productId,quantity: stockQty)

        when:
        DataImport.sendFeed(DataImport.stockJsonTemplateFile, stock)
        to(PDPPage, productId).addToCart()
        to(CartPage).updateItemQty(itemQtyToUpdate)

        then:
        at(CartPage).failedUpdatedQtyExceedAlert.isDisplayed()

    }
    def 'Update item with max available stock qty'(){
        given:
        def qty = 5
        def stock = new StockInfo(code: productId,quantity: qty)

        when:
        DataImport.sendFeed(DataImport.stockJsonTemplateFile, stock)
        to(PDPPage, productId).addToCart()
        to(CartPage).updateItemQty(qty)

        then:
        at(CartPage).successUpdatedQtyAlert.isDisplayed()

    }

    def 'Update item qty with 0'(){
        given:
        def qtyToUpdate = 0

        when:
        to(PDPPage, productId).addToCart()
        to(CartPage).updateItemQty(qtyToUpdate)

        then:
        at(CartPage).confirmationRemoveLink.isDisplayed()

    }
    def 'Update item qty with alfabetic characters'(){
        given:
        def qtyToUpdate = "@!#"

        when:
        to(PDPPage, productId).addToCart()
        to(CartPage).updateItemQty(qtyToUpdate)

        then:
        at(CartPage).failedUpdateQtyCharAlert.isDisplayed()

    }
}
