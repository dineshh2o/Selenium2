package spec.wlko.checkout

import model.Address
import model.Customer
import pageObject.page.CartPage
import pageObject.page.LoginPage
import pageObject.page.PDPPage
import pageObject.page.checkout.DeliveryAddressCheckoutPage
import pageObject.page.checkout.DeliveryMethodCheckoutPage
import pageObject.page.checkout.PaymentMethodCheckoutPage
import util.common.adminconsole.ImpexRunner
import util.wlko.flexibleSearch.GetProductData
import spec.CommonGebSpec

class CheckoutSpec extends CommonGebSpec {

    // WIP
    def 'Checkout as registered user'() {
        given:
        def customer = new Customer()
        ImpexRunner.executeImpex(ImpexRunner.customerAddImpex, customer)
        def productCode = GetProductData.getValidProductCode()
        def deliveryAddress = new Address()
        def deliveryMethod = 'SOME_CONST_HERE'

        when:
        to(LoginPage).login(customer.email, customer.password)
        to(PDPPage, productCode).addToCart()
        to(CartPage).clickCheckoutLink()
        //at(DeliveryAddressCheckoutPage).setAddress(deliveryAddress)
        at(DeliveryAddressCheckoutPage).clickNext()
        //at(DeliveryMethodCheckoutPage).setDeliveryMethod(deliveryMethod)
        at(DeliveryMethodCheckoutPage).clickNext()
        //at(PaymentMethodCheckoutPage).populateCardDetails()
        at(PaymentMethodCheckoutPage).clickNext()
        // TODO: at confirmation page click place order

        then:
        true
        //at(OrderConfirmationPage).message == "Successfully placed order"
    }
}
