package spec.wlko.checkout

import model.Customer
import pageObject.page.CartPage
import pageObject.page.PDPPage
import pageObject.page.checkout.AuthenticationPage
import pageObject.page.checkout.DeliveryMethodCheckoutPage
import spec.CommonGebSpec
import util.common.adminconsole.ImpexRunner
import util.wlko.flexibleSearch.GetCustomerData
import util.wlko.flexibleSearch.GetProductData

class AuthenticationPageSpec extends CommonGebSpec {

    def "Authentication page is displayed when anonymous user goes to Checkout"() {
        given:
        def productCode = GetProductData.getExistingSKU()

        when:
        to(PDPPage, productCode)
                .addToCart()
        to(CartPage)
                .checkoutBtn.click()

        then:
        at(AuthenticationPage)
    }

    def "User can login as registered user during checkout"() {

        given:
        def customer = new Customer()
        ImpexRunner.executeImpex(ImpexRunner.customerAddImpex, customer)
        def productCode = GetProductData.getExistingSKU()

        when:
        to(PDPPage, productCode)
                .addToCart()
        def expectedCartId = to(CartPage)
                .cartID.text()
        at(CartPage)
                .checkoutBtn.click()

        and:
        at(AuthenticationPage)
                .login(customer.email, customer.password)
        def actualCartId = GetCustomerData
                .getCartLinkedToCustomer(customer.userId)

        then:
        at(DeliveryMethodCheckoutPage)
        expectedCartId == 'ID: ' + actualCartId


    }

    def "Anonymous user can checkout as guest"() {
        given:
        def customer = new Customer()
        def productCode = GetProductData.getExistingSKU()

        when:
        to(PDPPage, productCode)
                .addToCart()
        def expectedCartId = to(CartPage)
                .cartID.text()
        at(CartPage)
                .checkoutBtn.click()

        and:
        at(AuthenticationPage)
                .loginAsGuest(customer.email)
        def actualCartId = GetCustomerData
                .getCartLinkedToCustomer(customer.userId)

        then:
        at(DeliveryMethodCheckoutPage)
        expectedCartId == 'ID: ' + actualCartId
    }

}
