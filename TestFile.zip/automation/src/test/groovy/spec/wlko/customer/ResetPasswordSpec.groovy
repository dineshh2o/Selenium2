package spec.wlko.customer

import model.Customer
import pageObject.page.HomePage
import pageObject.page.LoginPage
import pageObject.page.ResetPassword
import spock.lang.Shared
import util.wlko.flexibleSearch.GetCustomerData
import spec.CommonGebSpec
import util.common.adminconsole.ImpexRunner

class ResetPasswordSpec extends CommonGebSpec  {

    @Shared
    Customer customer = new Customer()
    @Shared
    def newPassword = '123456789b'

    def setupSpec(){
        ImpexRunner.executeImpex(ImpexRunner.customerAddImpex, customer)
    }

    def cleanupSpec(){
        ImpexRunner.executeImpex(ImpexRunner.customerRemoveImpex, customer)
    }


    def 'User is able to trigger reset password token'(){

        given:
        to(LoginPage)

        when:
        at(LoginPage).resetPassword(customer.email)

        then:
        waitFor { at(LoginPage).forgotPasswordForm.passwordResetAlert.displayed }

    }

    def 'User is able to change password using reset token'() {

        given:
        to(LoginPage)

        and:
        at(LoginPage).resetPassword(customer.email)

        when:
        String token = GetCustomerData.getCustomerToken(customer)
        to(ResetPassword, token).changePassword(newPassword)

        then:
        at(LoginPage).alertPasswordChanged.displayed
    }

    def 'User is able to login with new password'(){
        given:
        to(LoginPage).resetPassword(customer.email)

        and:
        String token = GetCustomerData.getCustomerToken(customer)
        to(ResetPassword, token).changePassword(newPassword)

        when:
        at(LoginPage).login(customer.userId, newPassword)

        then:
        at(HomePage)
    }
}
