package spec.wlko.customer

import model.Customer
import pageObject.page.HomePage
import pageObject.page.LoginPage
import pageObject.page.MyAccountPage
import spec.CommonGebSpec
import util.common.annotation.Smoke

class RegistrationSpec extends CommonGebSpec {

    @Smoke
    def 'User is able to register'() {
        given:
        Customer customer = new Customer()

        when:
        to(HomePage)
        at(HomePage).clickMyAccount()
        at(LoginPage).fillAndSubmitRegistrationForm(customer)

        then:
        at(MyAccountPage).alert.contains('Thank you for registering.')

        when:
        at(MyAccountPage).header.signOut()
        at(HomePage).clickMyAccount()
        at(LoginPage).login(customer.email, customer.password)

        then:
        at(MyAccountPage)
    }
}
