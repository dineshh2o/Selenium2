package spec.wlko.plp

import pageObject.page.HomePage
import pageObject.page.PDPPage
import pageObject.page.SearchResultsPage
import spec.CommonGebSpec

class SearchSpec extends CommonGebSpec {

    def 'Search and open product'() {
        given:
        def searchTerm = "st64"
        def searchedProductName = "TCP Rustic Bulb ST64 60W ES 1pk"

        when:
        to(HomePage)
        at(HomePage).search(searchTerm)

        then:
        at(SearchResultsPage).resultsMessage == "2 Products found"
        at(SearchResultsPage).clickProductName(searchedProductName)
        at(PDPPage)
    }

}
