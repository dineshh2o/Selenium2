package spec.wlko.plp

import pageObject.page.CartPage
import pageObject.page.PLPPage
import spec.CommonGebSpec
import util.common.annotation.Regression
import util.common.annotation.Smoke

class PLPSpec extends CommonGebSpec {

    @Smoke
    def 'Category Page Is Opened'() {
        given:
        def category = PLPPage.CATEGORY_GARDEN

        when:
        to(PLPPage, category)

        then:
        with(at(PLPPage)) {
            categoryBanner.text().toLowerCase() == category
            facets.displayed
            productItems.displayed
        }
    }

    @Regression
    def 'User is able to sort products by price on PLP'() {
        given:
        def category = PLPPage.CATEGORY_KITCHEN
        def sortOption = PLPPage.SORT_HIGH_TO_LOW

        when:
        to(PLPPage, category)
        at(PLPPage).sort(sortOption)

        then:
        def priceArray = at(PLPPage).getPrices()
        priceArray == priceArray.sort(false).reverse()

    }

    @Regression
    def 'User is able to filter products by brand'() {

        given:
        def category = PLPPage.CATEGORY_GARDEN

        when:
        to(PLPPage, category)
        at(PLPPage).filterByOption(PLPPage.FILTER_BY_BRAND_WILKO)

        then:
        at(PLPPage).productsAreFiltered(PLPPage.FILTER_BY_BRAND_WILKO)

    }

    //@Smoke
    def 'Add to cart from PLP'() {
        given:
        def category = PLPPage.CATEGORY_DIY

        when:
        to (PLPPage, category)
        at(PLPPage).atb.click()
        at(PLPPage).miniCart.continueShopping.click()

        then:
        waitFor { at(PLPPage).cartTotal.text() == "1" }

        when:
        waitFor { at(PLPPage).miniCartLink.click() }
        at(PLPPage).miniCart.checkoutButton.click()

        then:
        at(CartPage)
    }

}

