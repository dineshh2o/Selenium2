package spec.wlko.plp

import model.Product
import model.StockInfo
import pageObject.page.HomePage
import pageObject.page.SearchResultsPage
import util.wlko.flexibleSearch.GetProductData
import spec.CommonGebSpec
import util.wlko.api.DataImport
import util.common.adminconsole.ImpexRunner

class MiniCartSpec extends CommonGebSpec {

    def 'OOS error msg is displayed in Mini-Cart when stock finished'() {

        given:
        def productCode = GetProductData.getExistingSKU()
        def stock = new StockInfo(code: productCode, available: 1, reserved: 0)
        ImpexRunner.executeImpex(ImpexRunner.stockUpdateImpex, stock)

        when:
        to(HomePage)
        at(HomePage).search(productCode)
        at(SearchResultsPage).atb.click()
        at(SearchResultsPage).miniCart.continueShopping.click()
        at(SearchResultsPage).atb.click()


        then:
        at(SearchResultsPage).miniCart.unavailableMsg.text().contains("we only currently have 1 available right now")

    }

    def 'Error msg is displayed in Mini-Cart when max qty reached'() {

        given:
        def productCode = GetProductData.getExistingSKU()
        def product = new Product(code: productCode, base: 'P' + productCode, maxQty: 1, catalog: 'Online')
        def stock = new StockInfo(code: productCode, quantity: 100)
        DataImport.sendFeed(DataImport.stockJsonTemplateFile, stock)
        ImpexRunner.executeImpex(ImpexRunner.productUpdateImpex, product)

        when:
        to(HomePage)
        at(HomePage).search(productCode)
        at(SearchResultsPage).atb.click()
        at(SearchResultsPage).miniCart.continueShopping.click()
        at(SearchResultsPage).atb.click()


        then:
        at(SearchResultsPage).miniCart.unavailableMsg.text().contains("we only allow a maximum of 1")

        cleanup:
        product.with { (maxQty) = ' '}
        ImpexRunner.executeImpex(ImpexRunner.ProductUpdateImpex, product)

    }

}
