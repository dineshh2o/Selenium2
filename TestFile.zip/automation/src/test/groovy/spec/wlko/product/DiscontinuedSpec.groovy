package spec.wlko.product

import model.Catalog
import model.Product
import model.Script
import pageObject.page.EmptySearchPage
import pageObject.page.HomePage
import pageObject.page.PDPPage
import spec.CommonGebSpec
import util.common.adminconsole.GroovyScripts
import util.common.adminconsole.ImpexRunner
import util.wlko.flexibleSearch.GetProductData

class DiscontinuedSpec extends CommonGebSpec {

    static def productCode
    static def offlineDate
    static Product product

    def setupSpec() {
        productCode = GetProductData.getExistingSKU()
        offlineDate = (new Date() - 1).format('yyyy-MM-dd HH:mm:ss.SS')
    }

    def cleanupSpec() {
        product.offlineDate = ''
        ImpexRunner.executeImpex(ImpexRunner.ProductUpdateImpex, product)
    }

    def 'Products with offline date in past are discontinued on PDP'(){
        given:
        product = new Product(code: productCode, base: 'P' + productCode, offlineDate: offlineDate, catalog: Catalog.Online)

        when:
        ImpexRunner.executeImpex(ImpexRunner.ProductUpdateImpex, product)
        to(PDPPage, productCode)

        then:
        at(PDPPage).stockStatus == 'This product is discontinued'

    }

    def 'Products with offline date in past are not searchable'(){
        given:
        product = new Product(code: productCode, base: 'P' + productCode, offlineDate: offlineDate, catalog: Catalog.Online)

        when:
        ImpexRunner.executeImpex(ImpexRunner.ProductUpdateImpex, product)
        Script cronJob = new Script(name: GroovyScripts.CRON_JOB_INDEX)
        GroovyScripts.executeCrobJob(cronJob)
        to(HomePage).search(productCode)

        then:
        at(EmptySearchPage)
    }
}
