package spec.wlko.product

import model.Delivery
import model.DeliveryTypes
import model.Product
import pageObject.page.CartPage
import pageObject.page.PDPPage
import spec.CommonGebSpec
import spock.lang.Unroll
import util.common.adminconsole.ImpexRunner
import util.wlko.flexibleSearch.GetProductData
import util.common.annotation.Regression

class DeliverySpec extends CommonGebSpec  {

    static def DEFAULT_NAME = "Home Delivery"
    static def productCode
    static def productCode2

    static def changeDeliveryModesName(Boolean isDefault) {

        List deliveries = [DeliveryTypes.standard, DeliveryTypes.standardDirect, DeliveryTypes.heavy, DeliveryTypes.heavyDirect]

        deliveries.each {
            def delivery = new Delivery(code: it)

            if (isDefault) {
                delivery.name = DEFAULT_NAME
            } else {
                delivery.name = delivery.code
            }
            ImpexRunner.executeImpex(ImpexRunner.deliveryNamesUdpateImpex, delivery)
        }
    }

    def setupSpec() {
        productCode = GetProductData.getExistingSKU()
        productCode2 = GetProductData.getExistingSKU()
        changeDeliveryModesName(false)
    }

    def cleanupSpec() {
        changeDeliveryModesName(true)
    }

    @Unroll
    @Regression
    def "Product level delivery option "() {
        given:
        def product = new Product(code: productCode, base: 'P' + productCode)

        when:
        product.with { (direct, standard, heavy, instore) = [d, s, h, i] }
        ImpexRunner.executeImpex(ImpexRunner.productUpdateDeliveryDataImpex, product)
        to(PDPPage, productCode)

        then:
        at(PDPPage).checkDeliveries(result)

        where:
        d     | s     | h     | i     || result
        false | false | false | true  || [DeliveryTypes.instore]
        false | false | true  | false || [DeliveryTypes.heavy]
        false | false | true  | true  || [DeliveryTypes.instore]
        false | true  | false | false || [DeliveryTypes.standard, DeliveryTypes.premium]
        false | true  | false | true  || [DeliveryTypes.instore]
        false | true  | true  | false || [DeliveryTypes.heavy]
        false | true  | true  | true  || [DeliveryTypes.instore]
        true  | false | false | false || [DeliveryTypes.standardDirect]
        true  | false | false | true  || [DeliveryTypes.instore]
        true  | false | true  | false || [DeliveryTypes.heavyDirect]
        true  | false | true  | true  || [DeliveryTypes.instore]
        true  | true  | false | false || [DeliveryTypes.standardDirect]
        true  | true  | false | true  || [DeliveryTypes.instore]
        true  | true  | true  | false || [DeliveryTypes.heavyDirect]
        true  | true  | true  | true  || [DeliveryTypes.instore]
        false | false | false | false || [DeliveryTypes.standard, DeliveryTypes.premium, DeliveryTypes.order_collect]
    }

    @Unroll
    @Regression
    def 'Product level delivery days - value set'(){
        given:
        def product = new Product(code: productCode, base: 'P' + productCode, deliveryDays: 25)

        when:
        ImpexRunner.executeImpex(ImpexRunner.productUpdateDeliveryDataImpex, product)
        to(PDPPage, productCode)

        then:
        at(PDPPage).deliveryDesc.contains(product.deliveryDays + ' working days')

    }

    @Unroll
    @Regression
    def 'Product level delivery days - default value'(){
        given:
        def product = new Product(code: productCode, base: 'P' + productCode)

        when:
        product.with { (direct, standard, heavy, instore) = [d, s, h, i] }
        ImpexRunner.executeImpex(ImpexRunner.productUpdateDeliveryDataImpex, product)
        to(PDPPage, productCode)

        then:
        at(PDPPage).deliveryDesc.contains(result + ' working days')

        where:
        d 	  | s 	  | h 	  | i 	  || result
        false | false | true  | false || 7
        false | true  | false | false || 4
        false | true  | true  | false || 7
        true  | false | false | false || 28
        true  | false | true  | false || 28
        true  | true  | false | false || 28
        true  | true  | true  | false || 28
        false | false | false | false || 4


    }

    @Unroll
    @Regression
    def 'Cart level delivery option - 1 product'(){
        given:
        def product = new Product(code: productCode, base: 'P' + productCode)

        when:
        product.with { (direct, standard, heavy) = [d, s, h] }
        ImpexRunner.executeImpex(ImpexRunner.productUpdateDeliveryDataImpex, product)
        to(PDPPage, productCode)
        at(PDPPage).addToCart()
        to(CartPage)

        then:
        at(CartPage).checkDeliveries(result)

        where:
        d     | s     | h     || result
        false | false | true  || [DeliveryTypes.heavy]
        false | true  | false || [DeliveryTypes.standard, DeliveryTypes.premium]
        false | true  | true  || [DeliveryTypes.heavy]
        true  | false | false || [DeliveryTypes.standardDirect]
        true  | false | true  || [DeliveryTypes.heavyDirect]
        true  | true  | false || [DeliveryTypes.standardDirect]
        true  | true  | true  || [DeliveryTypes.heavyDirect]
        false | false | false || [DeliveryTypes.standard, DeliveryTypes.premium, DeliveryTypes.order_collect]
   }

    @Unroll
    @Regression
    def 'Cart level delivery option - 2 products'(){
        given:
        def product1 = new Product(code: productCode, base: 'P' + productCode)
        def product2 = new Product(code: productCode2, base: 'P' + productCode2)

        when:
        product1.with { (direct, standard, heavy) = [d1, s1, h1] }
        product2.with { (direct, standard, heavy) = [d2, s2, h2] }
        ImpexRunner.executeImpex(ImpexRunner.productUpdateDeliveryDataImpex, product1)
        ImpexRunner.executeImpex(ImpexRunner.productUpdateDeliveryDataImpex, product2)
        to(PDPPage, productCode)
        at(PDPPage).addToCart()
        to(PDPPage, productCode2)
        at(PDPPage).addToCart()
        to(CartPage)


        then:
        at(CartPage).checkDeliveries(result)

        where:
        d1     | s1     | h1     | d2     | s2     | h2     || result
        false  | false  | true   | false  | false  | false  || [DeliveryTypes.heavy]
        false  | false  | true   | false  | true   | false  || [DeliveryTypes.heavy]
        false  | false  | true   | true   | false  | false  || [DeliveryTypes.heavyDirect]
        false  | true   | false  | false  | false  | false  || [DeliveryTypes.standard, DeliveryTypes.premium]
        false  | true   | false  | false  | false  | true   || [DeliveryTypes.heavy]
        false  | true   | false  | true   | false  | false  || [DeliveryTypes.standardDirect]
        true   | false  | false  | false  | false  | false  || [DeliveryTypes.standardDirect]
        false  | true   | true   | true   | false  | false  || [DeliveryTypes.heavyDirect]
        true   | false  | true   | false  | true   | false  || [DeliveryTypes.heavyDirect]
        true   | true   | false  | false  | false  | true   || [DeliveryTypes.heavyDirect]
        false  | false  | false  | false  | false  | false  || [DeliveryTypes.standard, DeliveryTypes.premium, DeliveryTypes.order_collect]

    }

}
