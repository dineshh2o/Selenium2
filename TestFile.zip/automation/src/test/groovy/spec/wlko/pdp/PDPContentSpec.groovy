package spec.wlko.pdp

import model.PriceRow
import pageObject.page.PDPPage
import spec.CommonGebSpec
import util.wlko.flexibleSearch.GetProductData
import util.wlko.api.DataImport
import util.common.annotation.Smoke


class PDPContentSpec extends CommonGebSpec {

    @Smoke
    def 'PDP should contain correct elements'() {
        given:
        def productId = '0437652'

        when:
        to(PDPPage, productId)

        then:
        with(at(PDPPage)) {
            productName == "TCP Motion Sensor Bulb 10W BC 1pk 0437652"
            addToBasketButton.text() == "Add to basket"
            price == "£18.00"
            stockStatus == "In Stock"
            bulletPoint1 == "80% energy saving that lasts for up to 25 years"
            bulletPoint2 == "Provides a soft bright white warm light"
            bulletPoint3 == "Ideal replacement for 40w bulb"
            description == "Save money and energy with this LED Classic bulb with motion sensor, ideal for open hanging pendants in halls and landings."
        }
    }

    def 'Was price & saving are displayed on PDP'() {

        given:
        def productCode = GetProductData.getExistingSKU()
        def price = new PriceRow(code: productCode)

        when:
        DataImport.sendFeed(DataImport.priceRowTemplate, price)
        to(PDPPage, productCode)

        then:
        with(at(PDPPage)){
            wasPriceValue == price.wasprice
            savingValue == (price.wasprice - price.price).round(2)
        }

    }
}
