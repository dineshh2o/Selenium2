package spec.wlko.pdp

import model.Customer
import pageObject.page.LoginPage
import pageObject.page.PDPPage
import spock.lang.Shared
import util.wlko.flexibleSearch.GetCustomerData
import util.wlko.flexibleSearch.GetProductData
import spec.CommonGebSpec
import util.common.adminconsole.ImpexRunner

class EWBISSpec extends CommonGebSpec {

    @Shared
    Customer customer = new Customer()

    def setupSpec(){
        ImpexRunner.executeImpex(ImpexRunner.customerAddImpex, customer)
    }

    def cleanupSpec(){
        ImpexRunner.executeImpex(ImpexRunner.customerRemoveImpex, customer)
    }


    def 'Email is filled for registered user in Notify Me Form'() {

        given:
        def oosProduct = GetProductData.getOOSproduct()

        and:
        to(LoginPage).login(customer.email, customer.password)

        when:
        to(PDPPage, oosProduct)
        at(PDPPage).emailWhenBackInStock.click()

        then:
        at(PDPPage).notifyMe.email.value() == customer.email
    }

    def 'Registered User is able to create product interest'() {

        given:
        def oosProduct = GetProductData.getOOSproduct()

        and:
        to(LoginPage).login(customer.email, customer.password)

        when:
        to(PDPPage, oosProduct)
        at(PDPPage).emailWhenBackInStock.click()
        at(PDPPage).notifyMe.subscribeBtn.click()
        def subscribedProduct = GetProductData.getProductInterestsDetails(customer)

        then:
        subscribedProduct == oosProduct
    }

    def 'Email is empty for Guest user in Notify Me form'(){

        given:
        def oosProduct = GetProductData.getOOSproduct()

        when:
        to(PDPPage, oosProduct)
        at(PDPPage).emailWhenBackInStock.click()

        then:
        at(PDPPage).notifyMe.email.value() == ""

    }

    def 'Anonymous User is able to create product interest'() {

        given:
        def oosProduct = GetProductData.getOOSproduct()
        Customer guest = new Customer()

        when:
        to(PDPPage, oosProduct)
        at(PDPPage).emailWhenBackInStock.click()
        at(PDPPage).subscribeAsGuest(guest.email)
        def subscribedProduct = GetProductData.getProductInterestsDetails(guest)

        then:
        subscribedProduct == oosProduct

        cleanup:
        guest.userId = GetCustomerData.getGuestUID(guest)
        ImpexRunner.executeImpex(ImpexRunner.customerRemoveImpex, guest)
    }

}
