package spec.wlko.pdp

import model.StockInfo
import pageObject.page.PDPPage
import util.wlko.flexibleSearch.GetProductData
import spec.CommonGebSpec
import util.wlko.api.DataImport
import util.common.adminconsole.ImpexRunner
import util.common.annotation.Regression

class StockMessaging extends CommonGebSpec  {

    @Regression
    def 'OOS message is displayed on PDP - 0 available'() {
        given:
        def productCode = GetProductData.getExistingSKU()
        StockInfo stock = new StockInfo(code: productCode, quantity: 0)

        when:
        DataImport.sendFeed(DataImport.stockJsonTemplateFile, stock)
        to(PDPPage, productCode)

        then:
        with(at(PDPPage)) {
            stockStatus == PDPPage.OOS_MSG
            emailWhenBackInStock.text() == PDPPage.OOS_BTN
        }

        cleanup:
        stock.quantity = 100
        DataImport.sendFeed(DataImport.stockJsonTemplateFile, stock)
    }

    @Regression
    def 'Out Of Stock message is displayed on PDP - fully reserved'() {
        given:
        def productCode = GetProductData.getExistingSKU()
        StockInfo stock = new StockInfo(code: productCode, available: 5, reserved: 5)

        when:
        ImpexRunner.executeImpex(ImpexRunner.stockUpdateImpex, stock)
        to(PDPPage, productCode)

        then:
        with(at(PDPPage)) {
            stockStatus == PDPPage.OOS_MSG
            emailWhenBackInStock.text() == PDPPage.OOS_BTN
        }

        cleanup:
        stock.with { (available, reserved) = [50, 0] }
        ImpexRunner.executeImpex(ImpexRunner.stockUpdateImpex, stock)
    }

    @Regression
    def 'Low stock message is displayed on PDP - partially reserved'() {
        given:
        def productCode = GetProductData.getExistingSKU()
        StockInfo stock = new StockInfo(code: productCode, available: 50, reserved: 49)

        when:
        ImpexRunner.executeImpex(ImpexRunner.stockUpdateImpex, stock)
        to(PDPPage, productCode)

        then:
        with(at(PDPPage)) {
            stockStatus == PDPPage.LAST_IN_STOCK_MSG
            addToBasketButton.text() == PDPPage.ATB_MSG
        }

        cleanup:
        stock.with { (available, reserved) = [50, 0] }
        ImpexRunner.executeImpex(ImpexRunner.stockUpdateImpex, stock)
    }

    def 'In Stock message PDP'() {
        given:
        def productCode = GetProductData.getExistingSKU()
        StockInfo stock = new StockInfo(code: productCode, quantity: 50)

        when:
        DataImport.sendFeed(DataImport.stockJsonTemplateFile, stock)
        to(PDPPage, productCode)

        then:
        with(at(PDPPage)) {
            addToBasketButton.text() == "Add to basket"
            stockStatus == "In Stock"
        }
    }
}
