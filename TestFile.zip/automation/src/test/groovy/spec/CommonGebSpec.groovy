package spec

import geb.spock.GebReportingSpec
import pageObject.page.HomePage
import pageObject.page.LoginPage
import pageObject.page.PDPPage

abstract class CommonGebSpec extends GebReportingSpec {

    void setupSpec() {
        driver.manage().window().maximize()
    }

}