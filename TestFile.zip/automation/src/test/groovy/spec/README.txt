package spec


GENERAL USAGE NOTES
-------------------------------------------------------------------------------------------------
- Use this folder ONLY for Gec specifications for browser (UI/WEB) automation

- Thus, the base class of all specs in this package should be 'spec.CommonGebSpec', which extends 'GebReportingSpec'

-  ! DO NOT USE ! Geb classes 'GebSpec' or 'GebReportingSpec', use the abstract class 'CommonGebSpec' instead

- Any other types of spec/test should not be stored in this package


GEB SPEC EXAMPLE
-------------------------------------------------------------------------------------------------
    package spec.homepage

    import pageObject.page.homepage.HomepagePage
    import spec.CommonGebSpec


    class HomepageSpec extends CommonGebSpec { ... }
