package api.common

import api.ApiSpec
import model.Script
import util.common.adminconsole.GroovyScripts
import util.common.annotation.Smoke

class IndexingSpec extends ApiSpec  {

    @Smoke
    def 'Indexing Cron Job'() {
        given:
        Script cronJob = new Script(name: GroovyScripts.CRON_JOB_INDEX)

        when:
        def status = GroovyScripts.executeCrobJob(cronJob)

        then:
        status == GroovyScripts.STATUS_SUCCESS
    }
}
