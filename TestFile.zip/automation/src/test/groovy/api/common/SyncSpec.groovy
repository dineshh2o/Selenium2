package api.common

import api.ApiSpec
import model.Script
import util.common.adminconsole.GroovyScripts
import util.common.annotation.Smoke

class SyncSpec extends ApiSpec {

    @Smoke
    def 'Sync Product Catalogs'() {

        given:
        Script Job = new Script(name: GroovyScripts.PRODUCT_CATALOG)

        when:
        def status = GroovyScripts.syncCatalog(Job)

        then:
        status == GroovyScripts.syncCatalog(Job)
    }

    @Smoke
    def 'Sync Content Catalogs'() {

        given:
        Script Job = new Script(name: GroovyScripts.CONTENT_CATALOG)

        when:
        def status = GroovyScripts.syncCatalog(Job)

        then:
        status == GroovyScripts.syncCatalog(Job)
    }
}
