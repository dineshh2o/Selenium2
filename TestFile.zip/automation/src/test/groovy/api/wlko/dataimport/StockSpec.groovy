package api.wlko.dataimport

import api.ApiSpec
import model.Product
import util.common.adminconsole.ImpexRunner
import util.wlko.flexibleSearch.GetProductData
import model.StockInfo
import util.wlko.api.DataImport

class StockSpec extends ApiSpec {

    static def productId = "AT_Stock_product001"
    static Product product = new Product(code: productId, base: 'P' + productId)

    def setupSpec() {
        ImpexRunner.executeImpex(ImpexRunner.productAddImpex, product)
    }

    def cleanupSpec() {
        ImpexRunner.executeImpex(ImpexRunner.productRemoveImpex, product)
    }

    def 'Stock import absolute quantity'() {

        given:
        def stock = new StockInfo(code: productId)

        when:
        DataImport.sendFeed(DataImport.stockJsonTemplateFile, stock)

        then:
        def actualStock = GetProductData.getStockInfo(stock.code)
        actualStock.available == stock.quantity
    }

    def 'Stock import relative quantity'() {

        given:
        def originalQuantity = 5
        def addedQuantity = 2
        def stock = new StockInfo(code: productId, quantity: originalQuantity)
        DataImport.sendFeed(DataImport.stockJsonTemplateFile, stock)

        when:
        def newStock = new StockInfo(code: productId, quantity: addedQuantity, absolute: false)
        DataImport.sendFeed(DataImport.stockJsonTemplateFile, newStock)

        then:
        def actualStock = GetProductData.getStockInfo(stock.code)
        actualStock.available == stock.quantity + newStock.quantity
    }


}
