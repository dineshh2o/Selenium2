package api.wlko.dataimport

import api.ApiSpec
import model.PriceRow
import model.Response
import util.wlko.flexibleSearch.GetPriceRowData
import util.wlko.flexibleSearch.GetProductData
import util.wlko.api.DataImport
import util.common.annotation.Regression

class PriceSpec extends ApiSpec {

    @Regression
    def 'PriceImport'() {
        given:
        def productCode = GetProductData.getExistingSKU()
        PriceRow expectedPriceRow = new PriceRow(code: productCode)

        when:
        Response resp = DataImport.sendFeed(DataImport.priceRowTemplate,expectedPriceRow)

        then:
        resp.headers.status == 200
        PriceRow actualPriceRow = GetPriceRowData.getPriceRow(expectedPriceRow.code)
        expectedPriceRow.equalsTo(actualPriceRow)
    }

}
