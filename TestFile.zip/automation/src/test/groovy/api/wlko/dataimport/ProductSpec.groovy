package api.wlko.dataimport

import api.ApiSpec
import model.Product
import spock.lang.Shared
import util.wlko.api.DataImport
import util.common.annotation.Regression
import util.wlko.flexibleSearch.GetProductData

class ProductSpec extends ApiSpec {

    @Shared
    Product product = new Product()

    @Regression
    def 'Import product'() {

        when:
        DataImport.sendFeed(DataImport.productJsonTemplate, product)

        then:
        def baseProduct = GetProductData.getBaseProductData(product.code)
        def variant = GetProductData.getVariantData(product.code)
        product.equals(baseProduct, true)
        product.equals(variant, false)

        }

    def 'Update existing product with new values'() {
        given:
        DataImport.sendFeed(DataImport.productJsonTemplate, product)
        product.changeValues()

        when:
        DataImport.sendFeed(DataImport.productJsonTemplate, product)

        then:
        def updatedProduct = GetProductData.getBaseProductData(product.code)
        product.equals(updatedProduct, true)
    }

    def 'Update existing product trying to remove fields'() {
        given:
        DataImport.sendFeed(DataImport.productJsonTemplate, product)

        when:
        // assumption: following fields were selected to be optional: productType, manufacturer, classificationCategoryId.Age
        product.includeOptional = false
        DataImport.sendFeed(DataImport.productJsonTemplate, product)

        then:
        def updatedProduct = GetProductData.getBaseProductData(product.code)
        product.equals(updatedProduct, true)
    }
}
