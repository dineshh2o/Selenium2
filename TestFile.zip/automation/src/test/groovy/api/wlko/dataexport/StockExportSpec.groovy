package api.wlko.dataexport

import api.ApiSpec

import model.Response
import util.common.adminconsole.ImpexRunner
import util.wlko.api.DataExport
import util.wlko.flexibleSearch.GetProductData

class StockExportSpec extends ApiSpec {

    def 'Its possible to retrieve stock data using dataExport'() {
        given:
        def productCode = GetProductData.getExistingSKU()
        def product = GetProductData.getBaseProductData(productCode)
        def stock = GetProductData.getStockInfo(product.code)

        when:
        ImpexRunner.executeImpex(ImpexRunner.ProductUpdateImpex, product)
        Response resp = DataExport.getData('stock', product.supplier)

        then:
        resp.headers.status == 200
        resp.body.feedType == "com.wilko.common.data.stock.schema.v1.json.StockFeed"
        with(resp.body.stockItems) {
            productId.first() == product.code
            warehouseId.first() == stock.warehouseId
            quantity.first() == stock.available
            absolute.first() == true
            productName.value.first().first() == product.name
            discontinued.first() == false
        }
    }

    def 'Empty response is returned if no products found during DataExport'() {
        given:
        def productCode = GetProductData.getExistingSKU()
        def product = GetProductData.getBaseProductData(productCode)

        when:
        Response resp = DataExport.getData('stock', product.supplier)

        then:
        resp.headers.status == 200
        resp.body.feedType == "com.wilko.common.data.stock.schema.v1.json.StockFeed"
        resp.body.stockItems == []
    }
}
