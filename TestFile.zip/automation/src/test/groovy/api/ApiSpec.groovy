package api

import spock.lang.Specification

abstract class ApiSpec extends Specification {

}
