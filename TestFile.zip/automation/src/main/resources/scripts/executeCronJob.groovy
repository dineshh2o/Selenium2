package scripts

def service = spring.getBean('cronJobService')
def job = service.getCronJob('$name')
def synchronous = true
service.performCronJob(job, synchronous)