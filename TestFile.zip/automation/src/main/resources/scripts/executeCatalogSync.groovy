package scripts

/*
* notes:
* normally it should have been possible to run just executeCatalogSyncJob
*
* def result = service.executeCatalogSyncJob('wilkoProductCatalog')
*
* but for some reason it returns the following error
*
* ERROR [SyncWorker<00000120 1 of 1>] [CatalogVersionSyncWorker] error in worker SyncWorker<00000120 1 of 1> : Entity not found ( pk = 8796137882101 name = 'de.hybris.platform.persistence.processing_CronJob' type code = '501' db table = 'cronjobs')
*
* (please note that you should have something unsynchronised for error to appear, if everything is synched - no error appears)
*
* so we are getting job name using setupSyncJobService and after that run it
*
* if you'll ever want to investigate more, you can start with looking at the following classes:
* DefaultSetupSyncJobService
* CatalogVersionSyncCronJobModel
* SyncItemJobModel
* SyncItemCronJob
* SyncItemJob
*
* */


def service = spring.getBean('setupSyncJobService')
def syncJob = service.getCatalogSyncJob('$name')
// not sure if it will ever happen that getCronJobs will return null
// but just in case there is "createProductCatalogSyncJob" method in setupSyncJobService service, e.g. uncomment
// service.createProductCatalogSyncJob('$name')
def jobCode = syncJob.getCronJobs().last().code

def cronjobService = spring.getBean('cronJobService')
def job = cronjobService.getCronJob(jobCode)
def synchronous = true

cronjobService.performCronJob(job, synchronous)