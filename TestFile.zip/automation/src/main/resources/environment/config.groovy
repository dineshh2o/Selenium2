package environment

environments {

    local {
        baseUrl = "https://wilko.local:9002"
        cronUrl = "https://localhost:9002"
        dataimportUrl = "/dataimport/feed"
        dataexportUrl = "/dataexport"
        adminUrl = "/admin"
        backofficeUrl = "/backoffice"
    }

    dev {
        baseUrl = "https://wlk-d-www.ms.ycs.io"
        cronUrl = "https://wlk-d-fr-app-001.hybrishosting.com:9002"
        dataimportUrl = "/dataimport/feed"
        dataexportUrl = "/dataexport"
        adminUrl = "/hac"
        backofficeUrl = "/backoffice"
    }

}