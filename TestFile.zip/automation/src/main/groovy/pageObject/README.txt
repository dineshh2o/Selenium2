package pageObject.page
package pageObject.module


GENERAL USAGE NOTES
-------------------------------------------------------------------------------------------------
- Use pageObject.page package to store Geb Page Object files

- Use pageObject.module package to store Geb Module files

- The base class of all Page Objects in this package should be 'pageObject.page.CommonPage', which extends Geb's 'Page' class

-  ! DO NOT USE ! Geb class 'Page', use the abstract class 'CommonPage' instead


GEB PAGE OBJECT EXAMPLE
-------------------------------------------------------------------------------------------------
    package pageObject.page.homepage

    import pageObject.page.CommonPage

    class HomepagePage extends CommonPage { ... }
