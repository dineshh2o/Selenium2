package pageObject.page

import pageObject.page.modules.SearchBar
import pageObject.page.modules.Header



class HomePage extends CommonPage {

    static at = { $('body.page-homepage')}

    static content = {
        searchBar { module SearchBar}
        header { module Header }
    }

    SearchResultsPage search(def searchTerm) {
        searchBar.searchInput.value(searchTerm)
        searchBar.searchBtn.click()

        browser.at(SearchResultsPage)
    }

    def clickMyAccount() {
        header.myAccountLink.click()
    }
}