package pageObject.page

import model.DeliveryTypes
import org.openqa.selenium.Keys

class CartPage<T> extends CommonPage {

    static url = "/cart"

    static at = { $("body.page-cart") }

    static content = {
        standard { $("div.delivery-options-item__name", text: DeliveryTypes.standard) }
        premium { $("div.delivery-options-item__name", text: DeliveryTypes.premium)}
        order_collect { $("div.delivery-options-item__name", text: DeliveryTypes.order_collect)}
        standardDirect { $("div.delivery-options-item__name", text: DeliveryTypes.standardDirect)}
        heavy { $("div.delivery-options-item__name", text: DeliveryTypes.heavy)}
        heavyDirect { $("div.delivery-options-item__name", text: DeliveryTypes.heavyDirect)}
        checkoutBtn { $("button", text: contains("Checkout securely")).first()}
        cartID { $(".cart-id") }
        productCode {$("div.item__code").text()}
        removeLink {$("button.js-execute-entry-action-button",0)}
        confirmationRemoveLink {$("button.remove-cart-item-overlay__remove", text: contains("Yes, remove it"))}
        emptyBasket {$("p",text: contains("Your shopping basket is empty"))}
        qtyInputField {$("input.js-update-entry-quantity-input")}
        successUpdatedQtyAlert {$("div.alert", text: contains("Product quantity has been updated."))}
        failedUpdatedQtyExceedAlert {$("div.alert", text: contains("has been reduced to 3 from 4 due to insufficient stock."))}
        failedUpdateQtyCharAlert {$("div.alert", text: contains("Please provide a positive number to update the quantity of an item."))}
    }

    T checkDeliveries(List deliveries) {

        deliveries.each {
            checkDeliveryDisplayed(it)
        }

        (T) browser.page

    }

    private checkDeliveryDisplayed(def mode) {

        switch (mode) {
            case DeliveryTypes.standard:
                standard.displayed
                break
            case DeliveryTypes.premium:
                premium.displayed
                break
            case DeliveryTypes.heavy:
                heavy.displayed
                break
            case DeliveryTypes.heavyDirect:
                heavyDirect.displayed
                break
            case DeliveryTypes.standardDirect:
                standardDirect.displayed
                break
        }
    }
    T updateItemQty(def qty) {
        qtyInputField.value(qty)
        qtyInputField << Keys.ENTER

        (T) browser.page
    }

}
