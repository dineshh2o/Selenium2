package pageObject.page

import pageObject.page.modules.AccountNav
import pageObject.page.modules.Header

class MyAccountPage<T> extends CommonPage {

    static url = '/my-account'

    static at = { $("body.page-account")}

    static content = {
        alert                       { $("div.global-alerts > div.alert").text() }
        header                      { module Header}
        accountNav                  { module AccountNav}
        newEmail (wait: true)       { $("#profile\\.email") }
        confirmEmail                { $("#profile\\.checkEmail") }
        passwordField               { $("#profile\\.pwd") }
        submitBtn                   { $("button", text: "Save changes") }
    }

    T updateEmail(String email, String password) {

        accountNav.emailAddress.click()
        newEmail = email
        confirmEmail = email
        passwordField = password
        submitBtn.click()

        (T) browser.page
    }

}
