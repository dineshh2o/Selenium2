package pageObject.page

class EmptySearchPage extends CommonPage {

    static at = { $("body.page-searchEmpty")}
}