package pageObject.page

import model.Customer

class ResetPassword extends CommonPage {

    static at = { $("body.page-updatePassword")}

    static content = {
            password { $("#password")}
            confirmPassword { $("#updatePwd\\.checkPwd")}
            updateBtn { $('button', type: 'submit', 1)}
    }

    String convertToPath(String token) {
        def path = ""
        String encodedToken = URLEncoder.encode(token, "UTF-8")
        path = "/login/pw/change?token=" + encodedToken

        return path
    }

    LoginPage changePassword(String newPassword){
        password = newPassword
        confirmPassword = newPassword
        updateBtn.click()

        browser.at(LoginPage)
    }
}
