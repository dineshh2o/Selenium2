package pageObject.page

import model.DeliveryTypes
import pageObject.page.modules.MiniCart
import pageObject.page.modules.NotifyMeForm

class PDPPage<T> extends CommonPage {

    static at = { $("body.page-productDetails") }

    static content = {
        productName { $("div.product-title").text() }
        addToBasketButton (wait: true) { $("#addToCartButton") }
        price { $("div.pdp-price", 0).text() }
        wasPriceValue { $("span.pdp-was-price__value").text().replace("£", "") as Double }
        savingValue { $("span.pdp-you-save-price__value").text().replace("£", "") as Double }
        stockStatus { $("div.stock-wrapper").text() }
        bulletPoint1 { $("div.product-details > div > ul > li", 0).text() }
        bulletPoint2 { $("div.product-details > div > ul > li", 1).text() }
        bulletPoint3 { $("div.product-details > div > ul > li", 2).text() }
        description { $("div.product-details > div.description").last().text() }
        emailWhenBackInStock { $("button.outOfStock")}

        standard { $("p.delivery-option__heading > span", text: DeliveryTypes.standard) }
        premium { $("p.delivery-option__heading > span", text: DeliveryTypes.premium)}
        order_collect { $("p.delivery-option__heading > span", text: DeliveryTypes.order_collect)}
        standardDirect { $("p.delivery-option__heading > span", text: DeliveryTypes.standardDirect)}
        heavy { $("p.delivery-option__heading > span", text: DeliveryTypes.heavy)}
        heavyDirect { $("p.delivery-option__heading > span", text: DeliveryTypes.heavyDirect)}
        inStoreOnly { $("p.delivery-option__heading > span", text: DeliveryTypes.instore)}
        deliveryDesc { $("p.delivery-option__desc",0).text() }

        notifyMe (wait: true) { module NotifyMeForm}
        miniCart (wait: true) { module MiniCart }

    }

    static String OOS_MSG = "Out of Stock"
    static String OOS_BTN = "Email when in stock"
    static String LAST_IN_STOCK_MSG = "Buy Now - only 1 in Stock"
    static String ATB_MSG = "Add to basket"


    String convertToPath(Object[] args) {
        // for PDP we expect only one parameter - product id
        def path = ""
        if (args?.length == 1) {
            path = "/p/${args.first()}"
        }
        else {
            throw new RuntimeException("none/too many arguments passed to pdp page: ${args}")
        }

        return path
    }

    T checkDeliveries(List deliveries) {

        deliveries.each {
            checkDeliveryDisplayed(it)
        }

        (T) browser.page

    }

    private checkDeliveryDisplayed(def mode) {

        switch (mode) {
            case DeliveryTypes.standard:
                standard.displayed
                break
            case DeliveryTypes.premium:
                premium.displayed
                break
            case DeliveryTypes.heavy:
                heavy.displayed
                break
            case DeliveryTypes.heavyDirect:
                heavyDirect.displayed
                break
            case DeliveryTypes.standardDirect:
                standardDirect.displayed
                break
            case DeliveryTypes.instore:
                inStoreOnly.displayed
                break
        }
    }

    T addToCart() {
        addToBasketButton.click()
        miniCart.displayed
        (T) browser.page
    }

    T subscribeAsGuest(String email) {
        notifyMe.email = email
        notifyMe.subscribeBtn.click()
        notifyMe.displayed
        (T) browser.page
    }
}
