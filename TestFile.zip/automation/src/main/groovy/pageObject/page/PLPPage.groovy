package pageObject.page

import pageObject.page.modules.MiniCart

class PLPPage<T> extends CommonPage {

    static at = { $("body.pageType-CategoryPage") }

    static content = {
        categoryBanner { $("div.category-banner-slot") }
        facets { $('div', id: 'product-facet') }
        sortByTop { $('span.select2-selection', 0) }
        sortByBottom { $('div.pagination-sort-by-dropdown', 1) }
        resultsPerPageTop { $('div.pagination-show-per-page-dropdown', 0) }
        resultsPerPageBottom { $('div.pagination-show-per-page-dropdown', 0) }
        paginationTop { $('ul.pagination', 0) }
        paginationBottom { $('ul.pagination', 1) }
        productItems { $("div.product__grid") }
        productPrice { $("div.price") }
        productName { $("a.name") }

        cartTotal { $("span.nav-items-total").last() }
        miniCartLink (toWait: true) { $("div.nav-cart") }

        miniCart(wait: true) { module MiniCart }
        filterSelected { $(".facet__list__text--modified").text() }
        atb(toWait: true) { $("button", text: contains("Add to basket")).first() }
    }

    static CATEGORY_KITCHEN = 'kitchen'
    static CATEGORY_GARDEN = 'garden'
    static CATEGORY_DIY = 'diy'

    static SORT_HIGH_TO_LOW = 'Price (High to Low)'
    static FILTER_BY_BRAND_WILKO = 'Wilko'


    String convertToPath(Object[] args) {
        // for PLP we expect only one parameter - category
        def path
        if (args?.length == 1) {
            path = "/${args.first()}/c/${args.first()}"
        } else {
            throw new RuntimeException("none/too many arguments passed to plp page: ${args}")
        }

        return path
    }

    T sort(String sortOption) {
        sortByTop.click()
        def option = $(".select2-results__option", text: contains(sortOption))
        option.click()

        (T) browser.page
    }

    def getPrices() {
        def priceArray = []
        productPrice.each {
            def a = it.text().replace("£", "")
            priceArray.add(Double.parseDouble(a))
        }
        (T) browser.page
        return priceArray
    }

    T filterByOption(String filterOption) {
        $('span.facet__list__text', text: startsWith(filterOption)).click()

        (T) browser.page
    }

    T productsAreFiltered(String filterOption) {
        productName.each {
            assert it.text().startsWith(filterOption)
        }

        (T) browser.page
    }
}
