package pageObject.page

import geb.Page


abstract class CommonPage extends Page {


    def clickNext() {
        $("button", text: contains("Next")).click()
    }
}