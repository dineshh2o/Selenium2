package pageObject.page

import pageObject.page.modules.MiniCart

class SearchResultsPage extends PLPPage {

    static at = { $("body.page-search") }

    static content = {
        resultsMessage { $("div.pagination-bar-results",0).text() }
        miniCart(wait: true) { module MiniCart }
        atb(wait: true) { $("button", text: contains("Add to basket")).first() }
    }

    PDPPage clickProductName(String productName) {
        $("a.name", text: contains(productName)).click()
        return browser.at(PDPPage)
    }

}
