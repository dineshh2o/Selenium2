package pageObject.page.checkout

import pageObject.page.CommonPage
import pageObject.page.modules.CheckoutAsGuestForm
import pageObject.page.modules.LoginForm

class AuthenticationPage<T> extends CommonPage {

    static url = "/login/checkout"

    static at = { $("body.page-checkout-login") }

    static content = {
        loginForm(wait:true) { module LoginForm }
        guestCheckoutForm(wait:true) { module CheckoutAsGuestForm}
    }

    T login(String email, String password) {
        loginForm.email = email
        loginForm.password = password
        loginForm.signInBtn.click()

        (T) browser.page
    }

    T loginAsGuest(String email) {
        guestCheckoutForm.email = email
        guestCheckoutForm.confirmEmail = email
        guestCheckoutForm.signInBtn.click()

        (T) browser.page
    }
}
