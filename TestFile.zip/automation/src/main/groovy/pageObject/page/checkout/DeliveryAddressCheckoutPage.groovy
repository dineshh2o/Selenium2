package pageObject.page.checkout

import pageObject.page.CommonPage

class DeliveryAddressCheckoutPage extends CommonPage {
}
