package pageObject.page.checkout

import pageObject.page.CommonPage

class DeliveryMethodCheckoutPage extends CommonPage {

    static url = "/checkout/multi/delivery-method/choose"

    static at = { $("body.page-multiStepCheckoutSummaryPage")}
}
