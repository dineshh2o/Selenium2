package pageObject.page.checkout

import pageObject.page.CommonPage

class PaymentMethodCheckoutPage extends CommonPage {
}
