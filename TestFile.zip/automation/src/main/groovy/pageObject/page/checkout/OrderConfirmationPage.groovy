package pageObject.page.checkout

import pageObject.page.CommonPage

class OrderConfirmationPage extends CommonPage {
}
