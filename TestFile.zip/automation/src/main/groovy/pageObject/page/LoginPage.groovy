package pageObject.page

import model.Customer
import pageObject.page.modules.LoginForm
import pageObject.page.modules.RegistrationForm
import pageObject.page.modules.ForgotPasswordForm


class LoginPage extends CommonPage {

    static url = '/login'
    static at = { $('body.page-login') }

    static content = {
        loginForm { module LoginForm }
        registractionForm { module RegistrationForm }
        forgotPasswordForm (wait:true) { module ForgotPasswordForm }
        alertPasswordChanged { $(".alert", text: contains("Success! You can now login using your new password."))}
    }

    def login(String email, String password) {
        loginForm.email = email
        loginForm.password = password
        loginForm.signInBtn.click()

    }

    MyAccountPage fillAndSubmitRegistrationForm(Customer customer) {
        registractionForm.setTitle(customer.title)
        registractionForm.firstName.value(customer.firstName)
        registractionForm.lastName.value(customer.lastName)
        registractionForm.email.value(customer.email)
        registractionForm.password.value(customer.password)
        registractionForm.confirmPassword.value(customer.password)
        registractionForm.registerBtn.click()

        browser.at(MyAccountPage)

    }

    LoginPage resetPassword(String email){
        loginForm.resetPasswordLink.click()
        forgotPasswordForm.email = email
        forgotPasswordForm.resetBtn.click()

        browser.at(LoginPage)
    }
}