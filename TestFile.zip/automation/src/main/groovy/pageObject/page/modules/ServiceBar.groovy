package pageObject.page.modules

import geb.Module

class ServiceBar extends Module {
    static base = { $('div.service-bar') }
    static content = {
        account(wait: true) { $('mini-account') }
    }
}
