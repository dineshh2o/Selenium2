package pageObject.page.modules

import geb.Module

class LoginForm extends Module {
    static base = { $('#loginForm') }
    static content = {
        email { $('#j_username') }
        password { $('#j_password') }
        signInBtn { $('button', type: 'submit', text: contains("Log"))}
        resetPasswordLink { $("a.js-password-forgotten", 1) }
    }
}
