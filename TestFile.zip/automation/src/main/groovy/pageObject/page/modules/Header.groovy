package pageObject.page.modules

import geb.Module
import pageObject.page.HomePage

class Header extends Module {

    static base = { $(".desktop__nav")}
    static content = {
        myAccountLink { $("a", title: "Account") }
    }

    HomePage signOut() {
        // TODO - change to click signOut btn when it is available
        browser.go "/logout"
        browser.at(HomePage)
    }

}
