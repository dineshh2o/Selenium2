package pageObject.page.modules

import geb.Module
import org.openqa.selenium.By

class RegistrationForm<T> extends Module {

    // We can't use base here because values from "Title" dropdown are located outside register div
    //static base = { $("div.register__section") }

    static content = {
        titleField { $("#select2-registertitle-container")}
        firstName { $("#register\\.firstName")}
        lastName { $(name: "lastName") }
        email {$(name: "email")}
        password { $(name: "pwd") }
        confirmPassword {$(name: "checkPwd")}
        registerBtn { $("button", text: contains("Agree & continue")) }
    }

    T setTitle(String title) {
        titleField.click()
        $("li.select2-results__option", text: contains(title)).click()

        (T) browser.page
    }
}
