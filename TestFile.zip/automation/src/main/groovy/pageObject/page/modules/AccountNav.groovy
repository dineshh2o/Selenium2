package pageObject.page.modules

import geb.Module

class AccountNav extends Module {

    static base = { $(".accountNav")}

    static content = {

        emailAddress { $(title: "Email Address")}
    }
}
