package pageObject.page.modules

import geb.Module

class MiniCart extends Module {

    static base = { $('div.mini-cart') }

    static content = {
        checkoutButton { $("a", text: contains("Check Out")) }
        unavailableMsg { $(".unavailable-msg") }
        continueShopping { $(".btn", text: contains("Continue Shopping"))}
    }


}
