package pageObject.page.modules

import geb.Module

class CheckoutAsGuestForm extends Module {

    static base = { $('#guestForm') }
    static content = {
        email { $('#guest\\.email') }
        confirmEmail { $('#guest\\.confirm\\.email') }
        signInBtn { $('button', type: 'submit', text: contains("Guest checkout"))}
    }
}
