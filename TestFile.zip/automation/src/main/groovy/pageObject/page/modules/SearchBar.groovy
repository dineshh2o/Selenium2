package pageObject.page.modules

import geb.Module

class SearchBar extends Module {
    static base = { $('div.site-search') }

    static content = {
        searchInput { $("#js-site-search-input") }
        searchBtn { $("span.glyphicon-search")}
    }
}
