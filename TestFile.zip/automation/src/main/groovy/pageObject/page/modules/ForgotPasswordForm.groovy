package pageObject.page.modules

import geb.Module
import model.Customer
import pageObject.page.LoginPage

class ForgotPasswordForm<T> extends Module {

    static base = { $(".forgotten-password") }

    static content = {
        email(wait: true) { $(name: "email") }
        resetBtn { $('button', type: 'submit')}
        passwordResetAlert { $(".alert", text: contains("Password reset instructions have been sent to your e-mail address."), 1)}
        closeBtn { $('button#cboxClose') }
    }
}
