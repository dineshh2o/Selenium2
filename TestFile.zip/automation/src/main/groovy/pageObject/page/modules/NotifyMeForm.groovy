package pageObject.page.modules

import geb.Module

class NotifyMeForm extends Module {

    static base = { $("#cboxContent") }

    static content = {
        email(wait: true) { $("#emailAddress") }
        subscribeBtn { $("button#addInterestbtn") }
        closeBtn { $("button#cboxClose") }
    }
}
