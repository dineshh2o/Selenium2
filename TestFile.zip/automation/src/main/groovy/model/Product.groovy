package model

import static io.qala.datagen.RandomShortApi.Double
import static io.qala.datagen.RandomShortApi.english
import static io.qala.datagen.RandomShortApi.numeric

class Product extends DTO {

    String date = new Date().format('yyyy-MM-dd\'T\'HH:mm:ss.SSSXXX')
    String code = numeric(7)
    String base = "P" + code
    String catalog = "Staged"
    String name = "name for " + base
    String summary = "Summary for " + base
    Double age = Double(100.00).round(2)
    String manufacturer = 'Wilko'
    String productType = 'All Gifts'
    Boolean direct = false
    Boolean standard = false
    Boolean heavy = false
    Boolean instore = false
    Integer deliveryDays = 0
    String maxQty = ''
    String offlineDate = (new Date() + 1000).format('yyyy-MM-dd HH:mm:ss.SS')
    String supplier = english(4)
    Boolean includeOptional = true

    def equals(Product Product, Boolean isBase) {

        def result = true

        if (isBase) {
            if (base != Product.base || name != Product.name || summary != Product.summary || age != Product.age || manufacturer != Product.manufacturer || productType != Product.productType) { result = false }
        } else {
            if (code != Product.code || base != Product.base ) {result = false}
        }

        result

    }

    def changeValues() {
        name = 'updated ' + name
        summary = 'updated ' + summary
        age = Double(100.00).round(2)
        manufacturer = 'updated ' + manufacturer
        direct = true
        standard = true
        heavy = true
        instore = true
        supplier = 'updated ' + supplier
    }
}
