package model

import groovy.json.internal.LazyMap
import groovyx.net.http.HttpResponseDecorator

class Response  {
    HttpResponseDecorator headers
    LazyMap body
}
