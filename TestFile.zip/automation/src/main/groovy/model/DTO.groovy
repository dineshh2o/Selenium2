package model

abstract class DTO {
}
