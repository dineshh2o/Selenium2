package model

class Script extends DTO {
    String name
}
