package model

import static io.qala.datagen.RandomShortApi.integer

class StockInfo extends DTO {

    String date = new Date().format('yyyy-MM-dd\'T\'HH:mm:ss.SSSXXX')
    String code
    String warehouseId = "wilko-UK"

    // we use quantity for stock import
    Integer quantity = integer(100)
    Boolean absolute = true

    Integer available
    Integer reserved
    Integer preorder
    Integer maxpreorder
}
