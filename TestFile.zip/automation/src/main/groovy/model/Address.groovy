package model

import static io.qala.datagen.RandomShortApi.english
import static io.qala.datagen.RandomShortApi.numeric

class Address extends DTO {

    String country = "United Kingdom"
    String title = "Mr."
    String firstName = english(10)
    String lastName = english(10)
    String addressLine1 = english(20)
    String addressLine2 = english(20)
    String city = english(10)
    String postcode = "A9 9AA"
    String phoneNumber = numeric(9)
}
