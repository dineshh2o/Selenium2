package model

class DataProcessTask extends DTO {

    String taskId
    String queueId
    String handler
    String status
    LinkedHashMap payload
    String retryCount
    String maxRetryCount

}
