package model

enum Catalog {
    Staged,
    Online
}