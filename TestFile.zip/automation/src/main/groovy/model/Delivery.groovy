package model

class Delivery extends DTO {
    String code
    String name
}
