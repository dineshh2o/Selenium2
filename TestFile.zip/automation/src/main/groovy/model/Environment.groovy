package model

class Environment {

    def baseUrl
    def cronUrl
    def dataimportUrl
    def dataexportUrl
    def adminUrl
    def backofficeUrl
}
