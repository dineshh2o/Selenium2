package model

final class DeliveryTypes {

    public static final String standard = "uk-home-standard"
    public static final String standardDirect = "uk-home-standard-supplier-direct"
    public static final String heavy = "uk-home-heavy"
    public static final String heavyDirect = "uk-home-heavy-supplier-direct"
    public static final String premium = "Next Day Delivery"
    public static final String order_collect = "Order & Collect"
    public static final String instore = "In Store only"
}