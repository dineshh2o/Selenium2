package model

import static io.qala.datagen.RandomShortApi.Double
import static io.qala.datagen.RandomShortApi.numeric

class PriceRow extends DTO {

    String date = new Date().format('yyyy-MM-dd\'T\'HH:mm:ss.SSSXXX')
    String code = numeric(7)
    Double price = Double(20.00).round(2)
    Double wasprice = Double(20.00, 100.00).round(2)
    String currency = "GBP"
    String erpPromoRef = "test erp ref"

    def equalsTo(PriceRow priceRow) {

        def result = true

        if (code != priceRow.code || price != priceRow.price || wasprice != priceRow.wasprice || currency != priceRow.currency || erpPromoRef != priceRow.erpPromoRef) { result = false }

        result

    }
}
