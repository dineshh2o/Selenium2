package model

import static io.qala.datagen.RandomShortApi.english

class Customer extends DTO {

    String userId = "${english(10)}@wilkotest.co.uk".toLowerCase()
    String customerId = UUID.randomUUID().toString()
    String email = userId
    String firstName = english(10)
    String lastName = english(10)
    String name = firstName + '_' + lastName
    String password = '12345678a'
    String state = 'REGISTERED'
    String title = 'Mr.'
}
