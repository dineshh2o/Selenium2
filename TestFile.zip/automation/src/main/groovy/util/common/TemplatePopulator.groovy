package util.common

import groovy.text.GStringTemplateEngine
import model.DTO

class TemplatePopulator {

    static def populateTemplate (String templateFile, DTO  model){
        String templateContent = getClass().getResource(templateFile).text

        def engine = new GStringTemplateEngine()
        return engine.createTemplate(templateContent).make(model.properties).toString()
    }
}
