package util.common.adminconsole

import model.Script
import util.common.TemplatePopulator

class GroovyScripts {

    static def executeCronJobTemplate = '/scripts/executeCronJob.groovy'
    static String CRON_JOB_INDEX = 'full-wilkoIndex-cronJob'
    static String STATUS_SUCCESS = 'SUCCESS'

    static def executeCatalogSyncTemplate = '/scripts/executeCatalogSync.groovy'
    static String PRODUCT_CATALOG = 'wilkoProductCatalog'
    static String CONTENT_CATALOG = 'wilkoContentCatalog'

    static def executeCrobJob(Script cronJob) {


        def script = TemplatePopulator.populateTemplate(executeCronJobTemplate, cronJob)

        HybrisAdminExecutor.executeScript(script)

        def status = getCronJobStatus(cronJob.name)
        status
    }

    static def getCronJobStatus(String CronJobName) {

        def statusQuery = """
                            SELECT {r:code} FROM {cronJob AS cj JOIN CronJobResult AS r ON {r:pk}={cj:result}}
                            WHERE {cj:code}='$CronJobName'"""

        def result = HybrisAdminExecutor.runFlexibleSearch(statusQuery)

        def status = result['CODE'][0] as String
        status
    }

    static def syncCatalog(Script Job) {

        def script = TemplatePopulator.populateTemplate(executeCatalogSyncTemplate, Job)

        HybrisAdminExecutor.executeScript(script)

        def status = getSyncCronJobStatus(Job.name)
        status
    }

    static def getSyncCronJobStatus(String catalog) {

        def statusQuery = """
                            SELECT {r:code}
                            FROM {cronjob AS cj JOIN CatalogVersionSyncJob AS cvsj ON {cj:job}={cvsj:pk}
                            JOIN CronJobResult AS r ON {r:pk}={cj:result}}
                            WHERE {cvsj:code} LIKE '%$catalog%' ORDER BY {cj:endtime} DESC"""

        def result = HybrisAdminExecutor.runFlexibleSearch(statusQuery)

        def status = result['CODE'][0] as String
        status
    }
}
