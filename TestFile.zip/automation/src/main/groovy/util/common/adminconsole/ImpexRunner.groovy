package util.common.adminconsole

import model.DTO
import util.common.TemplatePopulator

class ImpexRunner {

    static def productUpdateDeliveryDataImpex = 'product_update_deliverydata'
    static def deliveryNamesUdpateImpex = 'deliveryName_update'
    static def ProductAddImpex = "product_add"
    static def ProductRemoveImpex = "product_remove"
    static def ProductUpdateImpex = "product_update"
    static def stockUpdateImpex = "stock_update"
    static def customerAddImpex = "customer_add"
    static def customerRemoveImpex = "customer_remove"

    static def executeImpex (String impexName, DTO model) {

        def impexFile = "/impex/${impexName}.impex"

        def impex= TemplatePopulator.populateTemplate(impexFile,model)
        HybrisAdminExecutor.runImpex(impex)
    }

}
