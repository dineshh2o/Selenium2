package util.common.adminconsole

import com.google.gson.Gson
import org.apache.http.client.methods.CloseableHttpResponse
import org.apache.http.client.methods.HttpGet
import org.apache.http.client.methods.RequestBuilder
import org.apache.http.conn.ssl.NoopHostnameVerifier
import org.apache.http.conn.ssl.TrustSelfSignedStrategy
import org.apache.http.impl.client.BasicCookieStore
import org.apache.http.impl.client.HttpClients
import org.apache.http.impl.client.LaxRedirectStrategy
import org.apache.http.ssl.SSLContexts
import org.apache.http.util.EntityUtils
import util.common.environment.TestContext

class HybrisAdminExecutor
{
    static String serverUrl = TestContext.env.cronUrl + TestContext.env.adminUrl

    static private final CSRF_REGEX = "<meta name=\"_csrf\" content=\"([^\"]+)"

    static private final LOGIN_URI = 'login.jsp'
    static private final CONFIG_URI = 'platform/config'
    static private final IMPEX_URI = 'console/impex/import'
    static private final FLEX_URI = 'console/flexsearch'
    static private final SCRIPT_URI = 'console/scripting'

    static private final LOGIN = 'admin'
    static private final PASSWORD = 'nimda'

    static private String csrf_token
    static private final ENCODING = 'UTF-8'

    static private sslContext = SSLContexts.custom()
                                           .loadTrustMaterial(null, new TrustSelfSignedStrategy())
                                           .build()
    static private cookieStore = new BasicCookieStore()
    static private httpClient = HttpClients.custom()
                                           .setDefaultCookieStore(cookieStore)
                                           .setSSLContext(sslContext)
                                           .setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE)
                                           .setRedirectStrategy(new LaxRedirectStrategy())
                                           .build()
    static private String MAXCOUNT = 1000

    static private String COMMIT = 'true'

    static def setHybrisProperty(String key, String value)
    {
        goToUrl("$serverUrl/$LOGIN_URI")
        authenticate()
        goToUrl("$serverUrl/$CONFIG_URI")

        def request = RequestBuilder.post()
                .setUri("$serverUrl/platform/configstore")
                .addParameter("key", key)
                .addParameter("val", value)
                .addParameter("_csrf", csrf_token)
                .build()
        def response = httpClient.execute(request)

        assert response.statusLine.statusCode == 200

        response.close()
    }

    static def runImpex(String query)
    {
        goToUrl("$serverUrl/$LOGIN_URI")
        authenticate()
        goToUrl("$serverUrl/$IMPEX_URI")

        def impexRequest = prepareImpexRequest(csrf_token, query)

        def response = httpClient.execute(impexRequest)
        assert response.statusLine.statusCode == 200
        assert responseBody(response).contains('Import finished successfully')

        response.close()
    }

    static private prepareImpexRequest(token, query)
    {
        def impexRequest = RequestBuilder.post()
                .setUri("$serverUrl/$IMPEX_URI")
                .addParameter("_csrf", token)
                .addParameter('scriptContent', query)
                .addParameter('validationEnum', 'IMPORT_STRICT')
                .addParameter('maxThreads', '2')
                .addParameter('encoding', 'UTF-8')
                .addParameter('_legacyMode', 'on')
                .addParameter('_enableCodeExecution', 'on')
                .addParameter('_distributedMode', 'on')
                .addParameter('_sldEnabled', 'on')
                .build()

        impexRequest
    }

    static def runFlexibleSearch(String query)
    {
        goToUrl("$serverUrl/$LOGIN_URI")
        authenticate()
        goToUrl("$serverUrl/$FLEX_URI")

        def flexRequest = prepareFlexibleSearchRequest(query, csrf_token, MAXCOUNT)

        def response = httpClient.execute(flexRequest)

        def entity = response.getEntity();
        def responseString = EntityUtils.toString(entity, "UTF-8");

        response.close()

        def gson = new Gson()
        def result = gson.fromJson(responseString, LinkedHashMap.class)

        return parseResult(result)
    }

    static private prepareFlexibleSearchRequest(query, token, maxcount)
    {
        def flexRequest = RequestBuilder.post()
                .setUri("$serverUrl/$FLEX_URI/execute")
                .addParameter('flexibleSearchQuery', query)
                .addParameter("_csrf", token)
                .addParameter("maxCount", maxcount)
                .build()

        flexRequest
    }

    static def executeScript(String script, String script_type='groovy'){
        goToUrl("$serverUrl/$LOGIN_URI")
        authenticate()
        goToUrl("$serverUrl/$SCRIPT_URI")

        def scriptRequest = RequestBuilder.post()
                .setUri("$serverUrl/$SCRIPT_URI/execute")
                .addParameter('script', script)
                .addParameter("_csrf", csrf_token)
                .addParameter("scriptType", script_type)
                .addParameter('commit', COMMIT)
                .build()

        def response = httpClient.execute(scriptRequest)
        assert response.statusLine.statusCode == 200
        def responseString = responseBody(response)
        response.close()

        def gson = new Gson()
        def result = gson.fromJson(responseString, LinkedHashMap.class)

        return result

    }

    static def parseResult(LinkedHashMap result)
    {
        ArrayList<LinkedHashMap> parsedHybrisItems = []

        result.resultList.each { row ->
            parsedHybrisItems << [result.headers, row].transpose().collectEntries { it }
        }
        return parsedHybrisItems
    }

    private static goToUrl(String url)
    {
        def request = new HttpGet(url)
        def response = httpClient.execute(request)
        updateCsrf(response)
        response.close()
    }

    static private authenticate()
    {
        def loginRequest = RequestBuilder.post()
                .setUri("$serverUrl/j_spring_security_check")
                .addParameter("j_username", LOGIN)
                .addParameter("j_password", PASSWORD)
                .addParameter("submit", "login")
                .addParameter("_csrf", csrf_token)
                .build()
        def authResponse = httpClient.execute(loginRequest)
        updateCsrf(authResponse)
        authResponse.close()
    }


    static private updateCsrf(response)
    {
        def responseString = responseBody(response)
        csrf_token = (responseString =~ /$CSRF_REGEX/)[0][1]
    }

    static private String responseBody(CloseableHttpResponse response)
    {
        def entity = response.getEntity();
        return EntityUtils.toString(entity, ENCODING);
    }
}
