package util.common.spocklistener

embedScreenshotsScript()

def embedScreenshotsScript() {
    try {
        def screenshotFiles = []
        def screenshotsDir = new File("build/reports/gradle/SpockListener_FailedTestScreenshots")
        def gradleIndexHTML = new File("build/reports/gradle/index.html")
        def htmlContent = gradleIndexHTML.text

        screenshotsDir.eachFile() { it -> screenshotFiles << it.getName() }

        screenshotFiles.each {
            def (testMethodName, extension) = it.tokenize('.')
            def screenshotHTMLLink = testMethodName +
                    """</a> <a href="../gradle/SpockListener_FailedTestScreenshots/${testMethodName}.png" >
                    <font color="red"><strong> SCREENSHOT </strong></font>
                    </a>"""
            htmlContent = htmlContent.replaceAll(testMethodName + "</a>", screenshotHTMLLink)
        }
        gradleIndexHTML.write(htmlContent)
    } catch (Exception e) {
        println "OMG !!! Caught an exeption: ${e.getMessage()}"
    }
}