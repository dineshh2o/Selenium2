package util.common.spocklistener

import com.google.common.io.Files
import util.common.environment.TestContext
import org.openqa.selenium.OutputType
import org.spockframework.runtime.AbstractRunListener
import org.spockframework.runtime.model.ErrorInfo
import org.openqa.selenium.TakesScreenshot


/**
 *  SPOCK TEST FAILURE LISTENER.
 *
 *      Description:
 *          - waits for fail test results and then create screenshots if found.
 *
 *      Implementation details:
 *          - we indirectly (see next point) use Spock's interface 'IRunListener' to achieve our goal
 *          - we use 'AbstractRunListener' class to implement only methods we need from contract specified by 'IRunListener'
 */
class TakeScreenshotIfTestFailsListener extends AbstractRunListener {

    void error(ErrorInfo error) {
        def driver = TestContext.driver
        if (driver) {
            File screenFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE)

            String fileName = generateScreenshotFileName(error)
            // generate file name based on test class and method names
            File destinationFolder = new File("build/reports/gradle/SpockListener_FailedTestScreenshots")
            destinationFolder.mkdirs()
            File destinationFile = new File(destinationFolder, fileName)

            Files.copy(screenFile, destinationFile)
        }
    }

    static String generateScreenshotFileName(ErrorInfo error) {
        String testName = (error.method.name)
        String fileName = testName + ".png"
        fileName
    }
}