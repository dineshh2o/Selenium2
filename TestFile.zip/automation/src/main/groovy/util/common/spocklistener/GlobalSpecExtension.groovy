package util.common.spocklistener

import org.spockframework.runtime.extension.IGlobalExtension
import org.spockframework.runtime.model.SpecInfo


/**
 *  - Add listener 'TakeScreenshotIfTestFailsListener' to our tests.
 *  - Use Spock extension mechanism by implementing 'IGlobalExtension'.
 *  - Register the global extention to Spock.
 *
 *  NOTE. Registering Spock global extension details: 'META-INF/services' directory, *.IGlobalExcention file
 */
class GlobalSpecExtension implements IGlobalExtension {

    @Override
    void start() {}

    @Override
    void visitSpec(SpecInfo specInfo) {
        specInfo.addListener(new TakeScreenshotIfTestFailsListener())
    }

    @Override
    void stop() {}
}