package util.common.environment

import model.Environment

class TestContext {

    static def driver

    static Environment env
}
