package util.common.environment

import model.Environment

class EnvironmentHelper {

    static def getEnvironment(envName) {
        def config = new ConfigSlurper(envName)
                        .parse(new File('src/main/resources/environment/config.groovy')
                        .toURI()
                        .toURL())

        def env = new Environment(
                        baseUrl: config.baseUrl,
                        cronUrl: config.cronUrl,
                        dataimportUrl: config.dataimportUrl,
                        dataexportUrl: config.dataexportUrl,
                        adminUrl: config.adminUrl,
                        backofficeUrl: config.backofficeUrl
        )
        env
    }

}
