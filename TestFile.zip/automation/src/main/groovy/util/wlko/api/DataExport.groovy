package util.wlko.api

import model.Response
import util.common.environment.TestContext

class DataExport {

    static getData(String dataType, String supplier) {
        def http = HttpBuilderConfig.configureHttpBuilder()
        def path = TestContext.env.dataexportUrl + '/' + dataType + '/' + supplier

        http.get(path: path) as Response
    }
}
