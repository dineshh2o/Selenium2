package util.wlko.api

import groovyx.net.http.HTTPBuilder
import util.common.environment.TestContext

class HttpBuilderConfig {

    static def configureHttpBuilder() {

        def httpBuilder = new HTTPBuilder(TestContext.env.cronUrl)
        httpBuilder.ignoreSSLIssues()
        httpBuilder.handler.success = { resp, reader ->
            [headers: resp, body: reader]
        }
        httpBuilder.handler.failure = { resp, reader ->
            [headers: resp, body: reader]
        }
        return httpBuilder
    }

}
