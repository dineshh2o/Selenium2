package util.wlko.api

import groovyx.net.http.ContentType
import model.DTO
import model.Response
import util.common.TemplatePopulator
import util.common.environment.TestContext

class DataImport {

    static def priceRowTemplate = "price"
    static def stockJsonTemplateFile = "stockSingle"
    static def productJsonTemplate = "product"


    static sendFeed(String feedName, DTO model) {
        def http = HttpBuilderConfig.configureHttpBuilder()
        def path = TestContext.env.dataimportUrl
        def feedFile = "/feedTemplate/${feedName}.tpl"
        def body = TemplatePopulator.populateTemplate(feedFile, model)

        http.post(path: path, body: body, requestContentType: ContentType.JSON) as Response
    }
}
