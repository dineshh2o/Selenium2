package util.wlko.flexibleSearch

import model.Customer
import util.common.adminconsole.HybrisAdminExecutor

@Singleton
class GetCustomerData {

    static def getCustomerToken(Customer customer) {

        def query="""SELECT {token} FROM {customer}
                     WHERE {uid} = '$customer.userId'"""

        def result = HybrisAdminExecutor.runFlexibleSearch(query)

        def token = result['P_TOKEN'][0] as String
        token
    }

    static def getGuestUID(Customer customer) {

        def query="""
                    SELECT {uid} FROM {customer}
                    WHERE {uid} like '%$customer.email'"""

        def result = HybrisAdminExecutor.runFlexibleSearch(query)

        def uid = result['P_UID'][0]
        uid
    }

    static getCartLinkedToCustomer (String uid) {

        def query="""SELECT {c:code}
                     FROM {cart AS c JOIN customer AS u ON {c:user}={u:pk}}
                     WHERE {u:uid} like '%$uid'"""

        def result = HybrisAdminExecutor.runFlexibleSearch(query)

        def cart = result['P_CODE'][0]
        cart
    }
}
