package util.wlko.flexibleSearch

import com.google.gson.Gson
import model.DataProcessTask
import util.common.adminconsole.HybrisAdminExecutor

class GetREData {

    static def GetDPTDetails() {

        // TODO - replace sleep by some waiting for customer to be created
        sleep(1000)
        def dptquery = """SELECT {taskId},{queueId},{handler},{status},{retryCount},{maxRetryCount}
                          FROM {DataProcessTask}
                          ORDER BY {creationtime} DESC LIMIT 1"""

        def result = HybrisAdminExecutor.runFlexibleSearch(dptquery)

        DataProcessTask dpt = new DataProcessTask(taskId: result['P_TASKID'][0],
                                                  queueId: result['P_QUEUEID'][0],
                                                  handler: result['P_HANDLER'][0],
                                                  status: result['P_STATUS'][0],
                                                  retryCount: result['P_RETRYCOUNR'][0],
                                                  maxRetryCount: result['P_MAXRETRYCOUNT'][0])

        dpt.payload = getREPayload()

        dpt
    }

    static def getREPayload() {
        def query  = """SELECT {pk} FROM {dataProcessTask} ORDER BY {creationtime} DESC LIMIT 1"""

        def script = """fs = spring.getBean('flexibleSearchService')
                        sr = fs.search("$query").getResult()
                        sr.each { println it.getPayload() }"""

        def result = HybrisAdminExecutor.executeScript(script)

        def re = result["outputText"]

        Gson gson = new Gson()
        def payload = gson.fromJson(re as String, LinkedHashMap.class)

        payload
    }
}
