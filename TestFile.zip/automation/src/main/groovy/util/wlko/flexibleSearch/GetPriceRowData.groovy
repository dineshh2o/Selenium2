package util.wlko.flexibleSearch

import model.PriceRow
import util.common.adminconsole.HybrisAdminExecutor

class GetPriceRowData {

    static def getPriceRow(String productCode){

        def priceRowQuery = """
                                SELECT {p:code},{pr:price},{pr:wasprice},{c:isocode},{pr:erpPromoRef}
                                FROM {pricerow as pr JOIN product as p on {pr:productId}={p:code} JOIN currency AS c ON {c:pk}={pr:currency} JOIN CatalogVersion AS cv ON {cv:pk}={p:catalogversion}}
                                WHERE {p:code} = '$productCode' AND {cv:version} = 'Staged'"""

        def result = HybrisAdminExecutor.runFlexibleSearch(priceRowQuery)

        PriceRow priceRow = new PriceRow(code:        result['P_CODE'][0] as String,
                                    price:       result['P_PRICE'][0] as Double,
                                    wasprice:    result['P_WASPRICE'][0] as Double,
                                    currency:    result['P_ISOCODE'][0] as String,
                                    erpPromoRef: result['P_ERPPROMOREF'][0] as String)
        priceRow
    }
}
