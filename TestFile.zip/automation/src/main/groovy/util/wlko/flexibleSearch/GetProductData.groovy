package util.wlko.flexibleSearch

import model.Customer
import model.Product
import model.StockInfo
import util.common.adminconsole.HybrisAdminExecutor

import static io.qala.datagen.RandomShortApi.*

class GetProductData {

    static def getValidProductCode() {
        // use an existing product as valid product
        // there is a risk that this product will be edited by manual testing
        // TODO: create a job that will insert products for automation and sync them to be available
        // (this is more time-consuming but assures we have valid product)
        "0437669"
    }

    static def getStockInfo(String productId, String warehouseId = "wilko-UK") {
        def stockQuery = """
                            SELECT {sl.productcode}, {sl.available}, {sl.reserved}, {sl.preorder}, {sl.maxpreorder}, {w.code}
                            FROM {stocklevel AS sl JOIN warehouse AS w ON {sl:warehouse} = {w:pk} }
                            WHERE {sl.productcode} = '$productId' AND {w.code} = '$warehouseId'
                          """

        def result = HybrisAdminExecutor.runFlexibleSearch(stockQuery)

        StockInfo stock = new StockInfo(code: productId,
                                        warehouseId: warehouseId,
                                        available: result['P_AVAILABLE'][0] as Integer,
                                        reserved: result['P_RESERVED'][0] as Integer,
                                        preorder: result['P_PREORDER'][0] as Integer,
                                        maxpreorder: result['P_MAXPREORDER'][0] as Integer)

        stock
    }

    static def getBaseProductData(String productCode) {
        def productQuery = """
                              SELECT {p:code},{p:name},{bp:text}, {p:type} AS type,
                              {p:manufacturerName} AS manufacturer, {p:directDelivery} AS direct,
                              {p:standardDeliveryOnly} AS standard, {p:heavydelivery} AS heavy, {p:inStoreOnly} AS instore
                              FROM {Product AS p JOIN BulletPoint AS bp ON {bp:product}={p:pk} JOIN CatalogVersion AS cv ON {p:catalogversion}={cv:pk}}
                              WHERE {p:code} = 'P$productCode' AND {cv:version}='Staged'"""

        def ageQuery = """
                                    SELECT {pf:numbervalue} AS age
                                    FROM {Product AS p JOIN ProductFeature AS pf ON {pf:product}={p:pk}}
                                    WHERE {p:code} = 'P$productCode' AND {pf:qualifier} like '%age%'
                                    ORDER BY {pf:creationtime} ASC"""

        def result1 = HybrisAdminExecutor.runFlexibleSearch(productQuery)
        def result2 = HybrisAdminExecutor.runFlexibleSearch(ageQuery)

        Product product = new Product(code: productCode,
                                      base: result1['P_CODE'][0],
                                      name: result1['P_NAME'][0],
                                      summary: result1['P_TEXT'][0],
                                      productType: result1['TYPE'][0],
                                      manufacturer: result1['MANUFACTURER'][0],
                                      age: result2['AGE'][0] as Double,
                                      direct:  result1['DIRECT'][0].toBoolean(),
                                      standard: result1['STANDARD'][0].toBoolean(),
                                      heavy: result1['HEAVY'][0].toBoolean(),
                                      instore: result1['INSTORE'][0].toBoolean())
        product
    }

    static def getVariantData(String productCode) {
        def variantQuery = """
                              SELECT {gvp:code} AS variant,{p:code} AS base
                              FROM {GenericVariantProduct AS gvp JOIN Product as p ON {p:pk}={gvp:baseproduct}}
                              WHERE {gvp:code} = '$productCode'"""

        def result = HybrisAdminExecutor.runFlexibleSearch(variantQuery)

        def variant = new Product(code:result['VARIANT'][0] as String,
                                  base:   result['BASE'][0] as String)
        variant
    }

    static def getExistingSKU() {

        def i = integer(10)

        def productCodeQuery = """
                                  SELECT {gvp:code}
                                  FROM {GenericVariantProduct as gvp JOIN CatalogVersion as cv ON {gvp:catalogversion}={cv:pk}
                                  JOIN ArticleApprovalStatus AS aas ON {gvp:approvalstatus}={aas:pk} JOIN Product AS p ON {gvp:baseproduct}={p:pk}
                                  JOIN StockLevel AS sl ON {sl:productCode}={gvp:code}}
                                  WHERE {cv:version}='Online' AND {aas:code}='approved' AND {p:inStoreOnly} = '0' AND {sl:available} > 1"""
        def result = HybrisAdminExecutor.runFlexibleSearch(productCodeQuery)

        def productCode = result['P_CODE'][i] as String

        if(productCode) {
            return productCode
        } else {
            throw new Exception("Product not found")
        }
    }

    static def getOOSproduct() {
        def i = integer(10)
        def OOSproductQuery = """
                                SELECT {gvp:code}
                                FROM {GenericVariantProduct as gvp JOIN StockLevel AS sl ON {sl:productCode}={gvp:code}
                                JOIN Product AS p ON {gvp:baseproduct}={p:pk}}
                                WHERE {sl:available} = '0' AND {p:inStoreOnly} = '0'"""

        def result = HybrisAdminExecutor.runFlexibleSearch(OOSproductQuery)

        def productCode = result['P_CODE'][i] as String

        if(productCode) {
            return productCode
        } else {
            throw new Exception("Product not found")
        }

    }

    static def getProductInterestsDetails(Customer customer){

        def productInterestQuery = """
                                    SELECT {p:code} FROM {ProductInterest AS pi JOIN Customer AS c ON {pi:customer}={c:pk}
                                    JOIN Product AS p ON {pi:product}={p:pk}}
                                    WHERE {c:uid} like '%$customer.userId'"""

        def result = HybrisAdminExecutor.runFlexibleSearch(productInterestQuery)

        def productCode = result['P_CODE'][0]
        productCode
    }

}
